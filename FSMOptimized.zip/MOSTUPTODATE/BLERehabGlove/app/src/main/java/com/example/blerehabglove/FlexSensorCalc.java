package com.example.blerehabglove;

import android.bluetooth.BluetoothGattCharacteristic;
import android.util.Log;
import java.nio.charset.StandardCharsets;

public class FlexSensorCalc {

    public static double calculatePosition(BluetoothGattCharacteristic c) {
        String s = new String(c.getValue(), StandardCharsets.UTF_8);
        double myDouble = Double.parseDouble(s);

        Log.w("FlexSensorCalc", "Value Received: "+ String.valueOf(myDouble));
        return myDouble;
    }
}
