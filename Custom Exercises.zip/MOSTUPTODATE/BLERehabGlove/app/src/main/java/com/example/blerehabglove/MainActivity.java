package com.example.blerehabglove;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.BLUETOOTH;
import static android.Manifest.permission.BLUETOOTH_ADMIN;

import static java.lang.String.valueOf;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


import java.nio.charset.StandardCharsets;
import java.util.UUID;


public class MainActivity extends AppCompatActivity implements BluetoothAdapter.LeScanCallback {
    private final static String TAG = MainActivity.class.getSimpleName();
    private static final String DEVICE_NAME = "Rehab Glove";
    private BluetoothAdapter mBluetoothAdapter;
    private SparseArray<BluetoothDevice> mDevices;
    private ProgressDialog mProgress;
    private BluetoothGatt mConnectedGatt;

    private static final int REQUEST_BLUETOOTH_ADMIN_ID = 1;
    private static final int REQUEST_LOCATION_ID = 2;
    private static final int REQUEST_BLUETOOTH_ID = 3;

    public static final UUID READ_SERVICE = UUID.fromString("00000001-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID THUMB_MEASUREMENT = UUID.fromString("00000002-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID INDEX_MEASUREMENT = UUID.fromString("00000003-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID MIDDLE_MEASUREMENT = UUID.fromString("00000004-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID RING_MEASUREMENT = UUID.fromString("00000005-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID PINKY_MEASUREMENT = UUID.fromString("00000006-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID DONE_FROM_PERIPHERAL = UUID.fromString("00000007-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID EXTRA_MEASUREMENT = UUID.fromString("00000008-627e-47e5-a3fc-ddabd97aa966");
    public static final UUID WRITE_SERVICE = UUID.fromString("00000001-627e-47e5-a3fc-ddabd97aa977");
    public static final UUID MOTOR_CONTROL = UUID.fromString("00000002-627e-47e5-a3fc-ddabd97aa977");
    public static final UUID SPEED_CONTROL = UUID.fromString("00000003-627e-47e5-a3fc-ddabd97aa977");
    public static final UUID POSITION_CONTROL = UUID.fromString("00000004-627e-47e5-a3fc-ddabd97aa977");
    public static final UUID DONE_FROM_APP = UUID.fromString("00000005-627e-47e5-a3fc-ddabd97aa977");

    private TextView mThumb, mIndex, mMiddle, mRing, mPinky, posTxt, spdTxt;

    //Read variables
    private double thumb_pos, index_pos, middle_pos, ring_pos, pinky_pos;
    private boolean done_perph;
    //Write variables
    private int motor_cont=0, speed_cont=50, pos_cont=50, thumb_bit=0, index_bit=0, middle_bit=0, ring_bit=0, pinky_bit=0;
    private boolean done_app, write_to_app=false, minimum_select=true;

    private Button writeButton;
    private SeekBar positionBar, speedBar;
    private ImageButton thumbButton, indexButton, middleButton, ringButton, pinkyButton;
    private ImageView posImg, spdImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setProgressBarIndeterminate(true);

        mThumb = (TextView) findViewById(R.id.thumb_text);
        mIndex = (TextView) findViewById(R.id.index_text);
        mMiddle = (TextView) findViewById(R.id.middle_text);
        mRing = (TextView) findViewById(R.id.ring_text);
        mPinky = (TextView) findViewById(R.id.pinky_text);

        positionBar = (SeekBar) findViewById(R.id.position_seekBar);
        speedBar = (SeekBar) findViewById(R.id.speed_seekBar);
        posTxt= (TextView) findViewById(R.id.pos_percent_text);
        spdTxt= (TextView) findViewById(R.id.speed_percent_text);

        posImg = findViewById(R.id.positionImg);
        spdImg = findViewById(R.id.speedImg);

        positionBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                posTxt.setText(valueOf(i)+"%");
                pos_cont = i;
                if(i<33)
                    posImg.setImageResource(R.drawable.zero_hand);
                else if(i<66)
                    posImg.setImageResource(R.drawable.fifty_hand);
                else
                    posImg.setImageResource(R.drawable.hundred_hand);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                spdTxt.setText(valueOf(i)+"%");
                speed_cont = i;
                if(i<33)
                    spdImg.setImageResource(R.drawable.turtle);
                else if(i<66)
                    spdImg.setImageResource(R.drawable.rabbit);
                else
                    spdImg.setImageResource(R.drawable.rocket);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        //Finger selection code
        thumbButton = (ImageButton) findViewById(R.id.thumb_button);
        thumbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(thumb_bit==0) {
                    thumbButton.setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                    thumb_bit = 1;
                }else{
                    thumbButton.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
                    thumb_bit = 0;
                }
            }
        });

        indexButton = (ImageButton) findViewById(R.id.index_button);
        indexButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index_bit==0) {
                    indexButton.setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                    index_bit = 1;
                }else{
                    indexButton.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
                    index_bit = 0;
                }
            }
        });

        middleButton = (ImageButton) findViewById(R.id.middle_button);
        middleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(middle_bit==0) {
                    middleButton.setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                    middle_bit = 1;
                }else{
                    middleButton.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
                    middle_bit = 0;
                }
            }
        });

        ringButton = (ImageButton) findViewById(R.id.ring_button);
        ringButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ring_bit==0) {
                    ringButton.setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                    ring_bit = 1;
                }else{
                    ringButton.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
                    ring_bit = 0;
                }
            }
        });

        pinkyButton = (ImageButton) findViewById(R.id.pinky_button);
        pinkyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(pinky_bit==0) {
                    pinkyButton.setColorFilter(Color.BLUE, PorterDuff.Mode.SRC_IN);
                    pinky_bit = 1;
                }else{
                    pinkyButton.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_IN);
                    pinky_bit = 0;
                }
            }
        });

        bleCheck();
        locationCheck();

        //Initializes a Bluetooth adapter.
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = manager.getAdapter();

        mDevices = new SparseArray<BluetoothDevice>();


        //A progress dialog will be needed while the connection process is taking place
        mProgress = new ProgressDialog(this);
        mProgress.setIndeterminate(true);
        mProgress.setCancelable(false);

        //Button to fully close hand, only exists for minimum standard
        writeButton = (Button) findViewById(R.id.hand_close_write);
        writeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                minimum_select = !minimum_select;
                if(!minimum_select) {
                    fingerSelect();
                    //motor_cont = 31;
                    //speed_cont = 100;
                    //pos_cont = 100;
                    done_app = false;
                    write_to_app = true;
                }else{
                    //motor_cont = 0;
                    //speed_cont = 0;
                    //pos_cont = 0;
                    done_app = true;
                    write_to_app = true;
                }
            }
        });
    }

    public void fingerSelect(){
        String binaryFingers = String.valueOf(pinky_bit)+String.valueOf(ring_bit)+String.valueOf(middle_bit)+String.valueOf(index_bit)+String.valueOf(thumb_bit);
        motor_cont=Integer.parseInt(binaryFingers,2); ;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Use this check to determine whether BLE is supported on the device.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
        }

        //Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

    }

    //IF SUPPRESSION IS ADDED HERE THE APP CRASHES
    @Override
    protected void onPause() {
        super.onPause();
        //Make sure dialog is hidden
        mProgress.dismiss();
        //Cancel any scans in progress
        mHandler.removeCallbacks(mStopRunnable);
        mHandler.removeCallbacks(mStartRunnable);
        mBluetoothAdapter.stopLeScan(this);
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onStop() {
        super.onStop();
        //Disconnect from any active tag connection
        if (mConnectedGatt != null) {
            mConnectedGatt.disconnect();
            mConnectedGatt = null;
        }
    }

    private void bleCheck() {
        if (ActivityCompat.checkSelfPermission(this, BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            // Bluetooth permission has not been granted.
            ActivityCompat.requestPermissions(this,new String[]{BLUETOOTH},REQUEST_BLUETOOTH_ID);
        }
        if (ActivityCompat.checkSelfPermission(this, BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            // Bluetooth admin permission has not been granted.
            ActivityCompat.requestPermissions(this, new String[]{BLUETOOTH_ADMIN}, REQUEST_BLUETOOTH_ADMIN_ID);
        }
    }

    private void locationCheck() {
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Location permission has not been granted.
            ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, REQUEST_LOCATION_ID);
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Add the "scan" option to the menu
        getMenuInflater().inflate(R.menu.main, menu);
        //Add any device elements we've discovered to the overflow menu
        for (int i=0; i < mDevices.size(); i++) {
            BluetoothDevice device = mDevices.valueAt(i);
            menu.add(0, mDevices.keyAt(i), 0, device.getName());
        }

        return true;
    }

    @SuppressLint("MissingPermission")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_scan: //Clears device list and rescans if scan is clicked again
                mDevices.clear();
                startScan();
                return true;
            default: //Any other button will connect to that service
                //Obtain the discovered device to connect with
                BluetoothDevice device = mDevices.get(item.getItemId());
                Log.i(TAG, "Connecting to "+device.getName());
                /*
                 * Make a connection with the device using the special LE-specific
                 * connectGatt() method, passing in a callback for GATT events
                 */
                mConnectedGatt = device.connectGatt(this, false, mGattCallback);
                //Display progress UI
                //mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Connecting to "+device.getName()+"..."));
                return super.onOptionsItemSelected(item);
        }
    }

    private void clearDisplayValues() {
        mThumb.setText("---");
        mIndex.setText("---");
        mMiddle.setText("---");
        mRing.setText("---");
        mPinky.setText("---");
    }


    private Runnable mStopRunnable = new Runnable() {
        @Override
        public void run() {
            stopScan();
        }
    };
    private Runnable mStartRunnable = new Runnable() {
        @Override
        public void run() {
            startScan();
        }
    };

    @SuppressLint("MissingPermission")
    private void startScan() {
        mBluetoothAdapter.startLeScan(this);
        setProgressBarIndeterminateVisibility(true);

        mHandler.postDelayed(mStopRunnable, 2500); //Scam lasts 2.5 seconds
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        mBluetoothAdapter.stopLeScan(this);
        setProgressBarIndeterminateVisibility(false);
    }

    /* BluetoothAdapter.LeScanCallback */
    @SuppressLint("MissingPermission")
    public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
        Log.i(TAG, "New LE Device: " + device.getName() + " @ " + rssi);
        /*
         * We are looking for RehabGlove devices only, so validate the name
         * that each device reports before adding it to our collection
         */
        if (DEVICE_NAME.equals(device.getName())) {
            mDevices.put(device.hashCode(), device);
            //Update the overflow menu
            invalidateOptionsMenu();
        }
    }

    /*
     * In this callback, we create a state machine to enforce that only
     * one characteristic be read or written at a time
     */
    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        /* State Machine Tracking */
        private int mState = 0;
        private void reset() { mState = 0; }
        private void advance() { mState++; }

        /* NOT NEEDED AS SENSORS ARE READ ONLY
         * Send an enable command to each sensor by writing a configuration
         * characteristic.  This is specific to the SensorTag to keep power
         * low by disabling sensors you aren't using.

        private void enableNextSensor(BluetoothGatt gatt) {
            BluetoothGattCharacteristic characteristic;
            switch (mState) {
                case 0:
                    Log.d(TAG, "Enabling pressure cal");
                    characteristic = gatt.getService(PRESSURE_SERVICE)
                            .getCharacteristic(PRESSURE_CONFIG_CHAR);
                    characteristic.setValue(new byte[] {0x02});
                    break;
                case 1:
                    Log.d(TAG, "Enabling pressure");
                    characteristic = gatt.getService(PRESSURE_SERVICE)
                            .getCharacteristic(PRESSURE_CONFIG_CHAR);
                    characteristic.setValue(new byte[] {0x01});
                    break;
                case 2:
                    Log.d(TAG, "Enabling humidity");
                    characteristic = gatt.getService(HUMIDITY_SERVICE)
                            .getCharacteristic(HUMIDITY_CONFIG_CHAR);
                    characteristic.setValue(new byte[] {0x01});
                    break;
                default:
                    mHandler.sendEmptyMessage(MSG_DISMISS);
                    Log.i(TAG, "All Sensors Enabled");
                    return;
            }

            gatt.writeCharacteristic(characteristic);
        }
        */

        //Read the data characteristic's value for each sensor explicitly
        @SuppressLint("MissingPermission")
        private void readNextSensor(BluetoothGatt gatt) {
            BluetoothGattCharacteristic characteristic;
            switch (mState) {
                case 0:
                    Log.d(TAG, "Reading Thumb Measurement");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(THUMB_MEASUREMENT);
                    break;
                case 1:
                    Log.d(TAG, "Reading Index Measurement");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(INDEX_MEASUREMENT);
                    break;
                case 2:
                    Log.d(TAG, "Reading Middle Measurement");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(MIDDLE_MEASUREMENT);
                    break;
                case 3:
                    Log.d(TAG, "Reading Ring Measurement");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(RING_MEASUREMENT);
                    break;
                case 4:
                    Log.d(TAG, "Reading Pinky Measurement");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(PINKY_MEASUREMENT);
                    break;
                case 5:
                    Log.d(TAG, "Reading Done From Perf");
                    characteristic = gatt.getService(READ_SERVICE)
                            .getCharacteristic(DONE_FROM_PERIPHERAL);
                    break;
                default:
                    mHandler.sendEmptyMessage(MSG_DISMISS);
                    Log.i(TAG, "Read Sweep Complete");
                    return;
            }

            gatt.readCharacteristic(characteristic);
        }
        //private int motor_cont, speed_cont, pos_cont;
        //private boolean done_app, write_to_app=false
        //Occurs after full read sweep once write_to_app flag is set true
        @SuppressLint("MissingPermission")
        private void writeNextSensor(BluetoothGatt gatt) {
            BluetoothGattCharacteristic characteristic;
            byte[] value = new byte[1];

            switch (mState) {
                case 6:
                    characteristic = gatt.getService(WRITE_SERVICE)
                            .getCharacteristic(MOTOR_CONTROL);
                    value[0] = (byte) (motor_cont);
                    Log.i(TAG, "Write Motor:");
                    break;
                case 7:
                    characteristic = gatt.getService(WRITE_SERVICE)
                            .getCharacteristic(SPEED_CONTROL);
                    value[0] = (byte) (speed_cont & 0xFF);
                    Log.i(TAG, "Write Speed:");
                    break;
                case 8:
                    characteristic = gatt.getService(WRITE_SERVICE)
                            .getCharacteristic(POSITION_CONTROL);
                    value[0] = (byte) (pos_cont & 0xFF);
                    Log.i(TAG, "Write Pos:");
                    break;
                case 9:
                    characteristic = gatt.getService(WRITE_SERVICE)
                            .getCharacteristic(DONE_FROM_APP);
                    value[0] = (byte) ((done_app ? 1 : 0 ) & 0xFF);
                    Log.i(TAG, "Write Done:");
                    break;
                default:
                    mHandler.sendEmptyMessage(MSG_DISMISS);
                    Log.i(TAG, "Write Sweep Complete");
                    return;
            }


            boolean status1 = false;

            //value[0] = (byte) (64 & 0xFF);
            characteristic.setValue(value);
            status1 = gatt.writeCharacteristic(characteristic);

            Log.i(TAG, "Write Val: "+Integer.toString(value[0])+" sucess?= "+status1);

        }

        @SuppressLint("MissingPermission")
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.d(TAG, "Connection State Change: "+status+" -> "+connectionState(newState));
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                /*
                 * Once successfully connected, we must next discover all the services on the
                 * device before we can read and write their characteristics.
                 */
                gatt.discoverServices();
                //mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Discovering Services..."));
            } else if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_DISCONNECTED) {
                /*
                 * If at any point we disconnect, send a message to clear the values
                 * out of the UI
                 */
                mHandler.sendEmptyMessage(MSG_CLEAR);
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                /*
                 * If there is a failure at any stage, simply disconnect
                 */
                gatt.disconnect();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.d(TAG, "Services Discovered: "+status);
            //mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Enabling Sensors..."));
            /*
             * With services discovered, we are going to reset our state machine and start
             * working through the sensors we need to enable
             */
            reset();
            readNextSensor(gatt);
        }

        public void startSensorRead(){

        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            //For each read, pass the data up to the UI thread to update the display
            if (THUMB_MEASUREMENT.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_THUMB, characteristic));
            }
            if (INDEX_MEASUREMENT.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_INDEX, characteristic));
            }
            if (MIDDLE_MEASUREMENT.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_MIDDLE, characteristic));
            }
            if (RING_MEASUREMENT.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_RING, characteristic));
            }
            if (PINKY_MEASUREMENT.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_PINKY, characteristic));
            }
            if (DONE_FROM_PERIPHERAL.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_DONE, characteristic));
            }



            if(DONE_FROM_PERIPHERAL.equals(characteristic.getUuid()) && !write_to_app) { //If at the end of a read, and write flag not set
                //Log.w(TAG, "STATE IF:"+ String.valueOf(mState));
                reset();
                readNextSensor(gatt);
            }else if(DONE_FROM_PERIPHERAL.equals(characteristic.getUuid()) && write_to_app){ //If at the end of a read, and write flag set
                advance();
                writeNextSensor(gatt);
            }else{ //Still reading
                //Log.w(TAG, "STATE ELSE:"+String.valueOf(mState));
                advance();
                readNextSensor(gatt);
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if(DONE_FROM_APP.equals(characteristic.getUuid())) { //If at the end of a write, return to read
                reset();
                readNextSensor(gatt);
            }else{ //Still reading
                //Log.w(TAG, "UUID: "+String.valueOf(characteristic.getUuid()));
                advance();
                writeNextSensor(gatt);
            }
        }

    /*
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            /*
             * After notifications are enabled, all updates from the device on characteristic
             * value changes will be posted here.  Similar to read, we hand these up to the
             * UI thread to update the display.

            if (HUMIDITY_DATA_CHAR.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_HUMIDITY, characteristic));
            }
            if (PRESSURE_DATA_CHAR.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE, characteristic));
            }
            if (PRESSURE_CAL_CHAR.equals(characteristic.getUuid())) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE_CAL, characteristic));
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            //Once notifications are enabled, we move to the next sensor and start over with enable
            advance();
            enableNextSensor(gatt);
        }
        */

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            Log.d(TAG, "Remote RSSI: "+rssi);
        }

        private String connectionState(int status) {
            switch (status) {
                case BluetoothProfile.STATE_CONNECTED:
                    return "Connected";
                case BluetoothProfile.STATE_DISCONNECTED:
                    return "Disconnected";
                case BluetoothProfile.STATE_CONNECTING:
                    return "Connecting";
                case BluetoothProfile.STATE_DISCONNECTING:
                    return "Disconnecting";
                default:
                    return valueOf(status);
            }
        }
    };


    // We have a Handler to process event results on the main thread
    private static final int MSG_THUMB = 101;
    private static final int MSG_INDEX = 102;
    private static final int MSG_MIDDLE = 103;
    private static final int MSG_RING= 104;
    private static final int MSG_PINKY = 105;
    private static final int MSG_DONE = 106;

    private static final int MSG_PROGRESS = 201;
    private static final int MSG_DISMISS = 202;
    private static final int MSG_CLEAR = 301;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            BluetoothGattCharacteristic characteristic;
            switch (msg.what) {
                case MSG_THUMB:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining thumb value");
                        return;
                    }
                    Log.w(TAG, "Thumb Reading: ");
                    updateFlexValue(characteristic, msg);
                    break;
                case MSG_INDEX:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining index value");
                        return;
                    }
                    Log.w(TAG, "Index Reading: ");
                    updateFlexValue(characteristic, msg);
                    break;
                case MSG_MIDDLE:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining middle value");
                        return;
                    }
                    Log.w(TAG, "Middle Reading: ");
                    updateFlexValue(characteristic, msg);
                    break;
                case MSG_RING:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining ring value");
                        return;
                    }
                    Log.w(TAG, "Ring Reading: ");
                    updateFlexValue(characteristic, msg);
                    break;
                case MSG_PINKY:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining pinky value");
                        return;
                    }
                    Log.w(TAG, "Pinky Reading: ");
                    updateFlexValue(characteristic, msg);
                    break;
                case MSG_DONE:
                    characteristic = (BluetoothGattCharacteristic) msg.obj;
                    if (characteristic.getValue() == null) {
                        Log.w(TAG, "Error obtaining done value");
                        return;
                    }
                    Log.w(TAG, "Done Reading: ");
                    //Need to import to get this to work
                    //done_perph = Boolean.parseBoolean(String(characteristic.getValue(), StandardCharsets.UTF_8));
                    break;


                case MSG_PROGRESS:
                    mProgress.setMessage((String) msg.obj);
                    if (!mProgress.isShowing()) {
                        mProgress.show();
                    }
                    break;
                case MSG_DISMISS:
                    mProgress.hide();
                    break;
                case MSG_CLEAR:
                    clearDisplayValues();
                    break;
            }
        }
    };


    /* Methods to extract sensor data and update the UI */
    private void updateFlexValue(BluetoothGattCharacteristic characteristic, Message msg) {
        double reading = FlexSensorCalc.calculatePosition(characteristic);
        String s = String.format("%.2f",reading);

        switch (msg.what) {
            case MSG_THUMB:
                thumb_pos = reading;
                mThumb.setText(s);
                break;
            case MSG_INDEX:
                index_pos = reading;
                mIndex.setText(s);
                break;
            case MSG_MIDDLE:
                middle_pos = reading;
                mMiddle.setText(s);
                break;
            case MSG_RING:
                ring_pos = reading;
                mRing.setText(s);
                break;
            case MSG_PINKY:
                pinky_pos = reading;
                mPinky.setText(s);
                break;
        }
    }

/*
    private void updateHumidityValues(BluetoothGattCharacteristic characteristic) {
        double humidity = SensorTagData.extractHumidity(characteristic);

        mHumidity.setText(String.format("%.0f%%", humidity));
    }

    private int[] mPressureCals;
    private void updatePressureCals(BluetoothGattCharacteristic characteristic) {
        mPressureCals = SensorTagData.extractCalibrationCoefficients(characteristic);
    }

    private void updatePressureValue(BluetoothGattCharacteristic characteristic) {
        if (mPressureCals == null) return;
        double pressure = SensorTagData.extractBarometer(characteristic, mPressureCals);
        double temp = SensorTagData.extractBarTemperature(characteristic, mPressureCals);

        mTemperature.setText(String.format("%.1f\u00B0C", temp));
        mPressure.setText(String.format("%.2f", pressure));
    }
 */
}



