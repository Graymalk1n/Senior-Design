package com.example.blerehabglove;

import android.bluetooth.BluetoothGattCharacteristic;
import android.util.Log;
import java.nio.charset.StandardCharsets;

public class FlexSensorCalc {

    public static double calculatePosition(BluetoothGattCharacteristic c) {
        /*TODO: This is where we will apply the linear regression to the sensor data to obtain
           position, for now. Use this data as raw values.
        */
        //int rawData = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 0);
        //double rawData = c.getValue();
        String s = new String(c.getValue(), StandardCharsets.UTF_8);
        //Log.w("FlexSensorCalc", "String from charval:"+ s);
        double myDouble = Double.parseDouble(s);

        Log.w("FlexSensorCalc", "Value Received: "+ String.valueOf(myDouble));
        return myDouble;
    }
}
