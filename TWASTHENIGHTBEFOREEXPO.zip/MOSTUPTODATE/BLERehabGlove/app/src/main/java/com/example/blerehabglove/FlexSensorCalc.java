package com.example.blerehabglove;

import static com.example.blerehabglove.MainActivity.MSG_INDEX;
import static com.example.blerehabglove.MainActivity.MSG_MIDDLE;
import static com.example.blerehabglove.MainActivity.MSG_PINKY;
import static com.example.blerehabglove.MainActivity.MSG_RING;
import static com.example.blerehabglove.MainActivity.MSG_THUMB;
import static java.lang.Math.log;

import android.bluetooth.BluetoothGattCharacteristic;
import android.os.Message;
import android.util.Log;
import java.nio.charset.StandardCharsets;

public class FlexSensorCalc {

    public static double calculatePosition(BluetoothGattCharacteristic c) {
        String s = new String(c.getValue(), StandardCharsets.UTF_8);
        double myDouble = Double.parseDouble(s);

        Log.w("FlexSensorCalc", "Value Received: "+ String.valueOf(myDouble));
        return myDouble;
    }

    public static String calculateprogress(Message msg, double reading){
        double progress = 0;
        String pecent = "";

        switch (msg.what) {
            case MSG_THUMB:
                if(6050*((log((reading-4.7432)/-1.28)/56.88))<0) {
                    pecent="0%";
                }else if(6050*((log((reading-4.7432)/-1.28)/56.88))>=100) {
                    pecent="Done";
                }else {
                    int conversion;
                    conversion = (int) (6050*((log((reading - 4.7432) / -1.28) / 56.88))) ;
                    progress = conversion.toString();
                    //progress = String.valueOf(conversion);
                }
                progress = (int) (reading * 1);
                break;
            case MSG_INDEX:
                progress = (int) (reading * 1);
                break;
            case MSG_MIDDLE:
                progress = (int) (reading * 1);
                break;
            case MSG_RING:
                progress = (int) (reading * 1);
                break;
            case MSG_PINKY:
                progress = (int) (reading * 1);
                break;
        }

        return pecent;
    }


}
